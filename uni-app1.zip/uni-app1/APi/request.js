//封装一个请求http
const baseUrl = 'http://unisurvey.cinnabarpear.top'; //根路径
let token = ''
export default (config = {}) => {
	//异步封装接口,使用Promise处理异步请求
	return new Promise((resolve, reject) => {
		//发送请求
		uni.request({
			url: baseUrl + config.url || '', //接收请求的API
			method: config.method || 'GET', //接收请求的方式,默认不传值为GET请求
			data: config.data || {}, //接收请求的data,不传默认为空
			header: { //封装请求头
				"Content-type": "application/x-www-form-urlencoded",
				"token": uni.getStorageSync('token')
			}
		}).then(data => {
			const [err, res] = data;
			const token = uni.getStorageSync('token')
			if (res.data.code === 201 && res.data.msg === "登录凭证已失效，请重新登录") {
				console.log(res.data);
				uni.removeStorageSync('token')
				uni.navigateTo({
					url: '/pages/login/login'
				})
			}
			console.log(res.data);
			resolve(res)

		}).catch(error => {
			reject(error)
		})
	})
}
