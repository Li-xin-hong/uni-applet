<script>
	export default {
		onLaunch: function() {
			//获取token判断是否登陆过,登陆过才建立长连接
			const token = uni.getStorageSync('token')
			//获取本地的userid
			const userid = uni.getStorageSync('userid')
			//当token存在时及登陆过才可以请求websocket长连接
			if (token) {
				//请求webSocket长连接
				//避免重复链接
				let is_open_socket = false
				//记录心跳检测的计时器
				let heartbeatlnterval = null
				//记录重新连接的间隔时间
				let reconnectTimeout = null
				//建立websocket连接
				let socketTask = uni.connectSocket({
					url: 'ws://unisurvey.cinnabarpear.top/websocket/140',
					success: e => {
						console.log(e);
					}
				})
				//心跳检测,定时给服务器发信息,来让服务器连接不断开
				function start(time) {
					heartbeatlnterval = setInterval(() => {
						socketTask.send({
							data: "我要一直连接",
							success: () => {
								console.log("连接请求发送成功");
							}
						})
					}, time)
				}
				//重新连接
				function reconnect() {
					//停止发送心跳
					clearInterval(heartbeatlnterval);
					//如果是自动关闭的话,那么就重新连接
					if (!is_open_socket) {
						reconnectTimeout = setTimeout(() => {
							socketTask = uni.connectSocket({
								url: 'ws://unisurvey.cinnabarpear.top/websocket/140',
								success: e => {
									console.log("重新建立websocket连接");
								}
							})
						}, 3000)
					}
				}
				监听websocket连接打开数据
				socketTask.onOpen((res) => {
					console.log("websocket连接正常");
					is_open_socket = true
					//开启心跳检测
					start(10000);
					socketTask.onMessage(e => {
						if (e.data == "websocket------") {
							console.log(e);
						} else {
							// e = JSON.parse(e.data)
							uni.setStorageSync('news', e)
						}
					})
				})
				//监听websocket连接关闭事件
				socketTask.onClose(res => {
					console.log("websocket已经被关闭");
					//不是人为关闭的
					is_open_socket = false
					//重新连接
					reconnect();
				})
			}
		},
		onShow: function() {
			console.log('App Show')
		},
		onHide: function() {
			console.log('App Hide')
		}
	}
</script>

<style lang="scss">
	/*每个页面公共css */
	@import '@/uni_modules/uni-scss/index.scss';
	/* #ifndef APP-NVUE */
	@import '@/static/customicons.css';

	// 设置整个项目的背景色
	page {
		background-color: #f5f5f5;
	}

	/* #endif */
	.example-info {
		font-size: 14px;
		color: #333;
		padding: 10px;
	}
</style>
