<template>
	<view>
		<view class="top">
			<text>{{title}}</text>
		</view>
		<view class="content">
			<view class="content-box">
				<text>党史知识竞赛</text>
				<image src="../../static/jiantou.png" mode="widthFix"></image>

			</view>
			<view class="content-box">
				<text>新员工培训考试</text>
				<image src="../../static/jiantou.png" mode="widthFix"></image>

			</view>
			<view class="content-box">
				<text>历史常识小测试</text>
				<image src="../../static/jiantou.png" mode="widthFix"></image>

			</view>
			<view class="content-box">
				<text>2021个人信息保护法知识测试</text>
				<image src="../../static/jiantou.png" mode="widthFix"></image>

			</view>
			<view class="content-box">
				<text>企业文化考试</text>
				<image src="../../static/jiantou.png" mode="widthFix"></image>

			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: "Casequestionnaire",
		props: {
			title: {
				type: String,
				default: ''
			}
		},
		data() {
			return {}
		},
	}
</script>

<style lang="scss">
	page {
		background-color: lightgray;
	}

	.top {
		width: 100%;
		height: 100rpx;
		text-align: center;
		line-height: 100rpx;
		font-family: "宋体";
		font-size: 56rpx;
		font-weight: bold;
	}

	.content {
		width: 80%;
		background-color: white;
		margin: auto;

		.content-box {
			display: flex;
			width: 100%;
			height: 100rpx;
			align-items: center;
			border-bottom: 2rpx solid lightgray;

			justify-content: space-between;

			text {
				padding-left: 20rpx;
			}

			image {
				width: 50rpx;
				padding-right: 5rpx;
			}
		}
	}
</style>
