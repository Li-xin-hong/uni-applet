<template>
	<view>
		<!-- 单选多选框区域 -->
<view class="boxa" 	>
	<navigator class="add" url="/subpkg/CreateQtn-kb-update/CreateQtn-kb-update?bl=true" style="border-right: 2rpx solid white">单选题</navigator>
	<navigator class="even" url="/subpkg/CreateQtn-kb-update/CreateQtn-kb-update?bl=false">多选题</navigator>
</view>
<!-- 题库区域 -->
<view class="question-bank">
	<text>题库</text>
	<!-- 题库内容区域 -->
	<view class="question-content">
		<!-- 选择题库题型区域 -->
		<swiper :indicator-dots="true" :autoplay="true" :interval="3000" :duration="1000" circular='true' indicator-color="white" indicator-active-color="blue">
			<swiper-item>
				<view class="swiper-item">好友关系链</view>
			</swiper-item>
			<swiper-item>
				<view class="swiper-item">移动端使用情况</view>
			</swiper-item>
			<swiper-item>
				<view class="swiper-item" @click="clicks">上网情况</view>
			</swiper-item>
			<swiper-item>
				<view class="swiper-item">人口属性</view>
			</swiper-item>
		</swiper>
		<!-- 尾部区域 -->
		<view class="buttom-content">
				<!-- 题库题目区域 -->
				<view class="content" :style="styles">
					<navigator url="#">电脑接入网络方式</navigator>
					<navigator url="#">电脑上网地点</navigator>
					<navigator url="#">手机上网网络</navigator>
					<navigator url="#">手机上网地点</navigator>
					<navigator url="#">上网设备</navigator>
				</view>
					<!-- 提交题目区域 -->
			    <button plain="true" @click="cancels">取消</button>
		</view> 
	</view>
</view>
	</view>
</template>

<script>
	export default {
		name:"CreateQtn-Home",
		data() {
			return {
				styles:'display: none;',//存储数据判断是否展示
				bl:true,//判断是展示还是隐藏
				displays:'display: none;'//存储当前页面组件的展示与隐藏
			};
		},
		methods:{
			clicks(){
				if(this.bl){
					this.styles=''
					this.bl=false
				}else{
					this.styles='display: none;'
					this.bl=true
				}
			},
			cancels(){
				this.$emit('cancels',this.displays)
			}
		}
	}
</script>

<style lang="scss">
.boxa{//单选题复选题最外层view样式
    position: relative;
	display: flex;
	width: 100%;
	navigator{
		color: white;
		width: 50%;
		height: 80rpx;
		text-align: center;
		line-height: 80rpx;
		border-bottom: 2rpx solid white;
	}
}

.question-bank{//题库区域最外层view样式
	text{
		display: block;
		font-family: "宋体";
		font-weight: bold;
		font-size: 56rpx;
		width: 100%;
		text-align: center;
		border-bottom: 1px solid white;
		height: 100rpx;
		line-height: 100rpx;
		margin-bottom: 20rpx;
	}
.swiper-item{//轮播图样式
	position: relative;
	left: 266rpx;
	width: 230rpx;
	height: 230rpx;
	border-radius: 50%;
	border: 1px solid white;
	text-align: center;
	line-height: 200rpx;
	color: white;
}
.buttom-content{
	.content{
		width: 100%;
		display: flex;
		flex-wrap: wrap;
		justify-content: space-between;
		animation: identifier 1s ;
		navigator{
			text-align: center;
			margin-top: 20rpx;
			width: 48%;
			height: 80rpx;
			line-height: 80rpx;
			border: 1px solid white;
		}
	}
	@keyframes identifier {
		0% {opacity: 0;}
		40%{opacity: 0.4;}
		100%{opacity: 1;}
	}
}
button{
	 position: absolute;
	 bottom: 0px;
	 border-top: 1px solid white;
	 width: 100%;
	 color: white;
	}
}
</style>