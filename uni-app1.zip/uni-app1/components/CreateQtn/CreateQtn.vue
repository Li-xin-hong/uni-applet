<template>
	<view>
		<view class="Template_detail_shopbtn_text_btn2" @click="checkChange">
			<view class="Template_detail_shopbtn_text_btn2_view" :class="checkvals?'upactive':''">
				<view class="Template_detail_shopbtn_text_btn2_view2" :class="checkvals?'activecss':''"></view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: "mycheckbox",
		props: {
			checked: {
				type: Boolean,
				default: true
			}
		},
		data() {
			return {
				checkvals: ''
			};
		},
		created() {
			this.checkvals = this.$props.checked
		},
		methods: {
			checkChange() {
				if (this.checkvals) {
					this.checkvals = false
				} else {
					this.checkvals = true
				}
			}
		}
	}
</script>

<style lang="scss" scoped>
	.Template_detail_shopbtn_text_btn2 {
		width: 20%;

	}

	.Template_detail_shopbtn_text_btn2_view {
		width: 35px;
		height: 18px;
		background: #D5D5D5;
		border-radius: 18px;
		margin-left: 20px;
	}

	.Template_detail_shopbtn_text_btn2_view2 {
		width: 16px;
		height: 16px;
		background: #FFFFFF;
		border-radius: 15px;
		float: right;
		margin-top: 1px;
		position: relative;
		right: 5rpx;
	}

	.upactive {
		background: #5E9BDE !important;
	}

	.activecss {
		background: #FFFFFF !important;
		float: left !important;
		position: relative;
		left: 5rpx;

	}
</style>
