<template>
	<view>
		<!-- 消息盒子 区域-->
		<view class="divs">
			<!-- 消息内容 -->
			<text>{{news}}</text>
		</view>
	</view>
</template>
<script>
	export default {
		name: "news",
		data() {
			return {
				news: '',
				show: true
			};
		},
		created() {
			this.news = uni.getStorageSync('news').msg
		},
		mounted() { //数据刷新时展示一次
			this.$emit('nws', this.show)
		},
	}
</script>

<style lang="scss">
	.divs {
		position: fixed;
		top: 0;
		left: 74rpx;
		width: 80%;
		height: 100rpx;
		border: 1rpx solid black;
		text-align: center;
		line-height: 100rpx;
		font-size: 36rpx;
		font-weight: bold;
		color: white;
		background-color: lightskyblue;
		border-radius: 50rpx;
	}
</style>
