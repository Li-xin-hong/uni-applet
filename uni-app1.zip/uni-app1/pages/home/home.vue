<template>
	<!-- 首页 -->
	<view>
		<!-- 提示消息模块 -->
		<news @nws="news" v-show="show">
		</news>
		<!-- 头部区域 -->
		<view class="top">
			<!-- 创建问卷 -->
			<navigator class="top-left" url="/subpkg/CreateQtn/CreateQtn">
				<image src="../../static/icon_5pzounbdxew/icon--tianjia.png" mode="heightFix"></image>
				<text>创建问卷</text>
			</navigator>
			<!-- 问卷模板 -->
			<navigator class="top-right" url="/subpkg/QuestionnaireTpt/QuestionnaireTpt">
				<image src="../../static/icon_5pzounbdxew/chazhao.png" mode="heightFix"></image>
				<text>问卷模板</text>
			</navigator>
		</view>
		<!-- 模板标题区域 -->
		<view class="service">
			<text>示例模板</text>
		</view>
		<!-- 模板内容区域 -->
		<view class=" TemplateContent">
			<view class="box1" v-for="(item,index) in list" :key="item.questionId" @click="skip(item.questionId)">
				<image :src="'http://unisurvey.cinnabarpear.top/showFile?name='+item.cover_url"></image>
				<view class="box2">
					<view class="box2-left">
						{{item.authority}}
					</view>
					<view class="box2-right">
						{{item.actual_num }}人参与
					</view>
				</view>
				<text>{{item.name}}</text>
			</view>

		</view>
	</view>
</template>

<script>
	//引入news消息模块
	import news from "../../components/news/news.vue"
	export default {
		onShow() {
			this.request();
		},
		data() {
			return {
				list: [],
				show: false
			};
		},
		methods: {
			//请求的方法
			async request() {
				const {
					data: res
				} = await this.$request({
					url: '/user/questions',
					methods: 'GET',
					data: {
						page: 1,
						page_size: 12
					}
				})
				this.list = res.data.list
				this.list.forEach(e => {
					if (e.authority === 'public') {
						e.authority = '公开问卷'
					} else if (e.authority === 'private') {
						e.authority = '私有问卷'
					}
				})
			},
			//官方示例,点击跳转到作答页面`
			skip(id) {
				uni.navigateTo({
					url: `../../subpkg/Details/Details?question_id=${id}`
				})
			},
			news(e) {
				this.show = e
				setTimeout(() => {
					this.show = false
				}, 3000)
			},
		},
		components: {
			news
		}
	}
</script>

<style lang="scss">
	.top {
		display: flex;
		width: 100%;

		image {
			height: 50rpx;
		}

		text {
			font-size: 24rpx;
			margin-top: 16rpx;
		}
	}

	.top-left {
		display: flex;
		justify-content: center;
		align-items: center;
		flex-direction: column;
		width: 50%;
		height: 150rpx;
		border-right: 1px solid lightgray;
		border-bottom: 1px solid lightgray;
	}

	.top-right {
		display: flex;
		justify-content: center;
		align-items: center;
		flex-direction: column;
		width: 50%;
		height: 150rpx;
		border-bottom: 1px solid lightgray;
	}

	.service {
		display: flex;
		justify-content: center;
		align-items: center;
		font-weight: bold;
		font-size: 36rpx;
		height: 150rpx;
		width: 100%;
		border-bottom: 1px solid lightgray;
	}

	.TemplateContent {
		display: flex;
		width: 100%;
		flex-wrap: wrap;
		justify-content: space-between;

		.box1 {
			display: flex;
			flex-direction: column;
			justify-content: center;
			align-items: center;
			width: 49.8%;
			height: 400rpx;
			border-bottom: 2rpx solid lightgray;

			image {
				width: 280rpx;
				height: 240rpx;
			}

			text {
				font-size: 24rpx;
				white-space: pre-wrap;
				width: 75%;
				letter-spacing: 4rpx;
				font-weight: bold;
				box-sizing: border-box;
				padding-top: 20rpx;
				padding-left: 8rpx;
			}

			.box2 {
				width: 70%;
				display: flex;
				font-size: 20rpx;
				justify-content: space-between;
				color: #C8CAC5;
				padding-top: 10rpx;

				.box2-left {
					width: 50%;
				}

				.box2-right {
					width: 50%;
					text-align: end;
				}
			}
		}

		.box1:nth-of-type(odd) {
			border-right: 2rpx solid lightgray;
		}
	}
</style>
<!-- 030105-->
