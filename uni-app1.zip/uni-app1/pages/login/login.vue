<template>
	<view>
		<!-- 登录页面 -->
		<view class="top">
			<text class="box1">欢迎使用小李问卷调查</text>
			<text class="box2">授权微信头像、昵称</text>
		</view>
		<view class="tupian">
			<image src="../../static/xinxi-.png" mode="widthFix"></image>
		</view>
		<view class="content">
			<text class="box1">为提供优质服务,问卷调查需要获取你的以下信息:</text>
			<text class="box2">•你的公开信息(头像、昵称等)</text>
		</view>
		<view class="bottom">
			<button @click="clicks">授权进入小李问卷调查</button>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				openID: ''
			};
		},
		onLoad() {
			const token = uni.getStorageSync(
				'token'
			) //获取一下本地的token看看是否已经存在,存在表示曾经登陆过
			//如果登陆过直接进入首页
			if (token) {
				uni.switchTab({
					url: '/pages/home/home'
				})
			}
		},
		methods: {
			clicks() {
				uni.getUserProfile({ //获取用户登录信息
					desc: '授权登录',
					lang: "zh_CN",
					success: res => {
						const nickName = res.userInfo.nickName
						const avatarUrl = res.userInfo.avatarUrl
						uni.login({ //调用微信官方接口登录API,获取唯一标识信息
							provider: 'weixin',
							success: (res) => {
								const mys = 'f8fd852f287f22785f857c991d263754'; //密钥
								const AppID = 'wx0eae66fd11a7238f'; //微信APPID
								//请求的获取openid的地址(需要四个参数)	
								const url =
									`https://api.weixin.qq.com/sns/jscode2session?appid=${AppID}&secret=${mys}&js_code=${res.code}&grant_type=authorization_code`;
								if (res.errMsg == 'login:ok') { //登录API,获取唯一标识信息成功
									uni.request({ //发送请求获取openid
										url: url,
										method: "GET",
										success: async (res) => {
											this.openID = res.data.openid;

											//发送请求获取token
											if (this.openID) { //判断是否获取到了openID
												const {
													data: res
												} = await this.$request({
													url: '/user/thirdplat/login',
													method: "POST",
													data: {
														open_id: this
															.openID,
														plat_info: 'weixin',
														type: 'wechat'
													}
												});
												const userid = res.data.id
												this.WebSocket();
												uni.setStorage({
													key: "token",
													data: res.data.token
												})
												uni.setStorageSync("nickName",
													nickName);
												uni.setStorageSync("avatarUrl",
													avatarUrl);
												uni.setStorageSync("userid",
													userid);
												uni.reLaunch({
													url: '/pages/home/home'
												})

											}

										}
									})
								}
							}
						})
					}
				});
			},
			WebSocket() {
				//请求webSocket长连接
				//避免重复链接
				let is_open_socket = false
				//记录心跳检测的计时器
				let heartbeatlnterval = null
				//记录重新连接的间隔时间
				let reconnectTimeout = null
				//建立websocket连接
				let socketTask = uni.connectSocket({
					url: 'ws://unisurvey.cinnabarpear.top/websocket/140',
					success: e => {
						console.log("再次发起一次请求");
					}
				})
				//心跳检测,定时给服务器发信息,来让服务器连接不断开
				function start(time) {
					heartbeatlnterval = setInterval(() => {
						socketTask.send({
							data: "我要一直连接",
							success: () => {
								console.log("连接请求发送成功");
							}
						})
					}, time)
				}
				//重新连接
				function reconnect() {
					//停止发送心跳
					clearInterval(heartbeatlnterval);
					//如果是自动关闭的话,那么就重新连接
					if (!is_open_socket) {
						reconnectTimeout = setTimeout(() => {
							socketTask = uni.connectSocket({
								url: 'ws://unisurvey.cinnabarpear.top/websocket/140',
								success: e => {
									console.log("重新建立websocket连接");
								}
							})
						}, 3000)
					}
				}
				//监听websocket连接打开数据
				socketTask.onOpen((res) => {
					console.log("websocket连接正常");
					is_open_socket = true
					//开启心跳检测
					start(10000);
					socketTask.onMessage(e => {
						if (e.data == "websocket连接") {
							console.log('被拦截掉的返回值', e);
						} else {
							e = JSON.parse(e.data)
							uni.setStorageSync('news', e)
						}
					})
				})
				//监听websocket连接关闭事件
				socketTask.onClose(res => {
					console.log("websocket已经被关闭");
					//不是人为关闭的
					is_open_socket = false
					//重新连接
					reconnect();
				})
			}

		}
	}
</script>

<style lang="scss">
	text {
		margin: 12rpx 0 0 16rpx;
		letter-spacing: 4rpx;
	}

	.top {
		display: flex;
		flex-direction: column;

		.box1 {
			font-size: 56rpx;
			font-weight: bold;
		}

		.box2 {
			font-size: 36rpx;
			color: lightgray;
		}
	}

	image {
		width: 500rpx;
		display: block;
		margin: auto;
	}

	.content {
		display: flex;
		flex-direction: column;

		.box1 {
			font-size: 26rpx;
		}

		.box2 {
			font-size: 20rpx;
			color: lightgray;
			margin: 38rpx 0 0 36rpx;
		}
	}

	.bottom {
		margin-top: 50rpx;
		width: 100%;

		button {
			width: 80%;
			color: white;
			letter-spacing: 2rpx;
			border-radius: 90rpx;
			background-color: #2680F0;
		}
	}
</style>
