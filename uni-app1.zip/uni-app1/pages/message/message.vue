<template>
	<!-- 个人中心页面 -->
	<view>
		<!-- 头像和昵称区域 -->
		<view class="top">
			<image :src="avatarUrl" mode="widthFix"></image>
			<text>{{nickName}}</text>
		</view>
		<!-- 功能区域 -->
		<view class="content">
			<view class="box1" style="margin-left:12%;">
				<view @click="skip">
					<image src="../../static/icon_5pzounbdxew/icon--tianjia.png" mode="widthFix"></image>
					<text style="padding-left:20rpx;">我创建的</text>
				</view>
				<image src="../../static/jiantou.png" mode="widthFix"></image>
			</view>
			<!-- ------------------------------------------------------------- -->
			<view class="box1" style="margin-left:12%;">
				<view @click="skips">
					<image src="../../static/icon_azm43al66eq/canyubiaojue.png" mode="widthFix"></image>
					<text style="padding-left:20rpx;">我参与的</text>
				</view>
				<image src="../../static/jiantou.png" mode="widthFix"></image>
			</view <!-- ------------------------------------------------------------- -->
			<view class="box1" style="margin-left:12%;">
				<view @click="skipx">
					<image src="../../static/icon_azm43al66eq/shoucang.png" mode="widthFix"></image>
					<text style="padding-left:20rpx;">我收藏的</text>
				</view>
				<image src="../../static/jiantou.png" mode="widthFix"></image>
			</view>
			<!-- ------------------------------------------------------------- -->
			<view class="box1" style="margin-left:12%;">
				<view>
					<image src="../../static/icon_azm43al66eq/kefu.png" mode="widthFix"></image>
					<button open-type="contact" style="border: none;margin: 0;padding: 16rpx;font-size: 35rpx;"
						plain="true">
						联系客服
					</button>
				</view>
				<image src="../../static/jiantou.png" mode="widthFix"></image>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				nickName: '', //用户昵称信息存储
				avatarUrl: '' //用户头像信息存储
			};
		},
		onShow() {
			this.nickName = uni.getStorageSync('nickName')
			this.avatarUrl = uni.getStorageSync('avatarUrl')
		},
		methods: {
			skip() { //我创建的跳转
				uni.navigateTo({
					url: "/subpkg/Icreated/Icreated"
				})
			},
			skips() { //我参与的问卷
				uni.navigateTo({
					url: '/subpkg/Participation /Participation '
				})
			},
			skipx() { //我收藏的问卷
				uni.navigateTo({
					url: '/subpkg/Enshrine/Enshrine'
				})
			},
		}
	}
</script>

<style lang="scss">
	.top {
		width: 100%;
		height: 340rpx;
		background-color: #52A8FB;
		display: flex;
		flex-direction: column;
		justify-content: space-evenly;
		align-items: center;
		color: white;

		image {
			width: 200rpx;
			border: 10rpx solid white;
			border-radius: 50%;
		}
	}

	.box1 {
		display: flex;
		width: 88%;
		height: 100rpx;
		align-items: center;
		border-bottom: 2rpx solid lightgray;
		justify-content: space-between;

		image {
			width: 40rpx;
			padding-right: 5rpx;
		}

		view {
			display: inline-flex;
			width: 50%;
			height: 100%;
			align-items: center
		}
	}
</style>
