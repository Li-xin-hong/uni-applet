<template>
	<view>
		<!-- 除空白页面以外的所有模板样子 -->
		<Casequestionnaire :title="title"></Casequestionnaire>
	</view>
</template>

<script>
	import Casequestionnaire from '@/components/Casequestionnaire/Casequestionnaire.vue'
	export default {
		data() {
			return {
				title:''
			};
		},
		onLoad() {
			//获取页面路径参数
			let routes = getCurrentPages(); // 获取当前打开过的页面路由数组
			 
			let curRoute = routes[routes.length - 1].route //获取当前页面路由
			 
			// 在微信小程序或是app中，通过curPage.options
			 
			// 如果是H5，则需要curPage.$route.query（H5中的curPage.options为undefined)
			let curParam = routes[routes.length - 1].options || routes[routes.length - 1].$route.query; //获取路由参数
			this.title=curParam.title
		},
		components:{
			Casequestionnaire
		}
	}
</script>

<style lang="scss">

</style>
