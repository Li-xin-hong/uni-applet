<template>
	<view>
		<view class="box">
			<text class="text">标题</text>
			<view class="boxs box-top">
				<view class="btss">
					<text>{{iptval}}</text>
					<text>{{iptval1}}</text>
				</view>
				<navigator url="/subpkg/CreateQtn-kb-bj/CreateQtn-kb-bj">编辑</navigator>
			</view>
			<text class="text">问题</text>
			<view class="xs">
				<view class="xuanxiang" v-for="(item,index) in list" :key="item.id">
					<image src="../../static/shanchu.png" mode="widthFix" @click="remove(item.id)"></image>
					<navigator :url="'/subpkg/CreateQtn-kb-update/CreateQtn-kb-update?id='+item.id" class="bt">
						{{item.title}}
					</navigator>
				</view>
				<view>
					<view style="font-size: 24rpx;color: lightskyblue;height: 60rpx;" @click="add">添加问题
						<!-- @click="show" -->
					</view>
				</view>
			</view>
			<!-- ------------------------------------------------------------------------------ -->
			<view class="box-content">
				<view class="box-kg" id="box-content1">
					<text>题目必答</text>
					<mycheckbox :checked="checekval" @click.native="change(1)"></mycheckbox>
				</view>
				<view class="box-kg" id="box-content1">
					<text>是否公开</text>
					<mycheckbox :checked="checekval" @click.native="change(2)"></mycheckbox>
				</view>
				<view class="box-kg" id="box-content1">
					<text>分类</text>
					<picker mode="selector" :range="arrays" :value="index" range-key="name" @change="classifychange">
						<view>{{arrays[index].name}}</view>
					</picker>
				</view>
				<view class="box-kg" id="box-content1">
					<uni-section :title="'日期时间范围用法：' + '[' + datetimerange + ']' " type="line"></uni-section>
					<view class="example-body">
						<uni-datetime-picker v-model="datetimerange" type="datetimerange" rangeSeparator="至" />
					</view>
				</view>
				<view class="box-kg" id="box-content1">
					<text>理想人数</text>
					<input type="number" placeholder="请输入理想的人数" v-model="numbers">
				</view>
			</view>
			<!-- 获取问卷调查封面图片区域 -->
			<view class="cover">
				<image :src="'http://unisurvey.cinnabarpear.top/showFile?name='+url" mode="widthFix" style="margin-bottom: 50rpx;
				width: 500rpx;"></image>
				<button @click="cover">选择封面图片</button>
			</view>
			<view class="box-buttom">
				<button @click="preserve">保存问卷</button><button>发布问卷</button>
			</view>
		</view>
		<view class="TJ-issue" :style="hide">
			<CreateQtnHome @cancels='getcancels'></CreateQtnHome>
		</view>
	</view>
</template>

<script>
	import mycheckbox from '@/components/CreateQtn/CreateQtn.vue'
	import CreateQtnHome from '@/components/CreateQtn-Home/CreateQtn-Home.vue'
	export default {
		data() {
			return {
				//存储获取到的页面参数,并渲染到页面上
				iptval: '问卷标题',
				iptval1: '为了给您提供更好的服务,希望您能抽出几分钟时间,将您的感受和建议告诉我们,我们非常重视每位用户的宝贵意见,期待您的参与！现在我们就马上开始吧！', //问卷描述
				hide: 'display:none;',
				checekval: true, //存储开关按钮的开关值(记录问卷是否否是必填项)
				iptvals: '', //记录问卷题目
				shuju: [], //记录问卷选项
				radio: '', //记录问卷选项是单选还是多选
				ids: '', //记录分类的ID值
				datetimerange: '', //选择开始和结束的时间
				datetimerangebegin: '', //记录问卷开始的时间
				datetimerangefinish: '', //记录问卷结束的时间
				url: '', //记录问卷的封面url地址
				arrays: [], //存储选择的分类
				index: 2, //默认展示的选择分类的下标
				numbers: '', //理想人数
				switchval: true, //存储是否公开的值
				objs: {}, //每一个标题下的所有数据(标题=>选项等等)
				obj: {
					content: ''
				},
				optionss: [],
				options: [],
				list: [{ //页面展示题目
					id: 1,
					title: '请输入题目标题',
				}],
				id: 0, //最后一个id值
			};
		},
		async created() { //请求分类列表数据
			const {
				data: res
			} = await this.$request({
				url: '/catalogs',
				data: {
					page: 1,
					page_size: 7
				}
			})
			this.arrays = res.data.list
			this.ids = this.arrays[this.index].id
		},
		onLoad(options) {
			//获取页面路径参数
			let routes = getCurrentPages(); // 获取当前打开过的页面路由数组

			let curRoute = routes[routes.length - 1].route //获取当前页面路由

			// 在微信小程序或是app中，通过curPage.options

			// 如果是H5，则需要curPage.$route.query（H5中的curPage.options为undefined)
			let curParam = routes[routes.length - 1].options || routes[routes.length - 1].$route.query; //获取路由参数


			// 拼接参数(当前只有一条参数,不需要进行参数拼接)
			let param = ''
			for (let key in curParam) {
				param += '&' + key + '=' + curParam[key]

			}
			this.iptval = curParam.iptval
			this.iptval1 = curParam.iptval1
			// ----------------------------------------------
			//接受子页面传过来的值
			uni.$on("datas", (options) => {
				this.radio = options.radio
				this.iptvals = options.iptvals
				this.shuju = options.list
				this.list.forEach(e => {
					if (e.id == options.titleid) {
						e.title = options.iptvals
					}
				})
				this.objs = { //每一个标题下的所有数据(标题=>选项等等)
					iptvals: this.iptvals, //记录问卷的题目
					list: this.shuju, //问卷选项
					radio: this.radio, //问卷是单选还是多选
				}
				this.obj = {
					content: this.objs,
					step_id: options.titleid
				}
				this.optionss.push(this.obj)
			});
		},
		onShow() {
			const title = uni.getStorageSync('title');
			this.iptval = title.iptval
			this.iptval1 = title.iptval1
			console.log(title);
		},
		methods: {
			remove(id) {
				this.list = this.list.filter(e => {
					if (e.id != id) {
						return e
					}
				})
				this.optionss = this.optionss.filter(e => {
					if (e.step_id != id) {
						return e
					}
				})
			},
			add() {
				if (this.list.length > 0) {
					this.id = this.list[this.list.length - 1].id
					this.id++;
					this.list.push({
						id: this.id
					});
				} else if (this.list.length == 0) {
					this.id++;
					this.list.push({
						id: this.id
					});
				}
				uni.navigateTo({
					url: `/subpkg/CreateQtn-kb-update/CreateQtn-kb-update?id=${this.id}`
				})
			},
			classifychange(e) { //分类的方法
				this.index = e.detail.value;
				this.ids = this.arrays[this.index].id
			},
			change(e) {
				if (e === 1) {
					if (this.checekval) {
						this.checekval = false
					} else {
						this.checekval = true
					}
				} else if (e === 2) {
					if (this.switchval) {
						this.switchval = false
					} else {
						this.switchval = true
					}
				}
			},
			show() { //通过show点击展示出隐藏的组件
				this.hide = ''
			},
			getcancels(e) {
				this.hide = e
			},
			async preserve() { //创建调查问卷
				if (this.switchval) {
					this.switchval = "public"
				} else {
					this.switchval = "private"
				}
				this.datetimerangebegin = this.datetimerange[0]
				this.datetimerangefinish = this.datetimerange[1]
				this.optionss.forEach(e => { //记录问卷是否为必答项
					e.content.checekval = this.checekval
				})
				console.log(this.optionss);
				this.options = JSON.stringify(this.optionss) //将问卷题目选项等数据转化为json格式
				console.log(this.options);
				const { //发送请求创建调查问卷
					data: res
				} = await this.$request({
					url: '/user/question',
					method: 'POST',
					data: {
						authority: this.switchval,
						catalog_id: this.ids,
						cover_url: this.url,
						description: this.iptval1,
						start_date: this.datetimerangebegin,
						end_date: this.datetimerangefinish,
						expected_num: this.numbers,
						name: this.iptval,
						options: this.options
					},
				});
				//保存问卷跳转到首页
				if (this.datetimerangebegin != '' && this.numbers != '' && this.options != '' && this.iptval != '' &&
					this.url != '') {
					uni.removeStorageSync('title')
					uni.switchTab({
						url: "../../pages/home/home"
					})
				} else {
					uni.showToast({
						title: "您有信息未填写",
						icon: 'error'
					})
				}
			},
			cover() {
				uni.chooseImage({
					count: 1, //默认1
					sizeType: ['original', 'compressed'], //可以指定是原图还是压缩图，默认二者都有
					sourceType: ['album', 'camera '], //从相册选择
					success: (res) => {
						const data = res.tempFilePaths[0]
						uni.uploadFile({
							url: 'http://unisurvey.cinnabarpear.top/upload',
							header: {
								"Content-type": "application/x-www-form-urlencoded",
								"token": uni.getStorageSync('token')
							},
							fileType: "image",
							filePath: data,
							name: "file",
							success: (res) => {
								this.url = JSON.parse(res.data).data
							}
						})
					}
				})
			}

		},
		components: {
			CreateQtnHome,
			mycheckbox
		}
	}
</script>

<style lang="scss">
	page {
		height: 100%;
		position: relative;
		background-color: #F3F4F8;
	}

	.TJ-issue {
		position: absolute;
		bottom: 1px;
		width: 100%;
		height: 80%;
		background-color: #52A8FB;
	}

	.xs {
		margin-top: 20px;
		width: 80%;
		margin: auto;
		box-shadow: 4rpx 4rpx 10rpx lightgray;
		background-color: white;

		image {
			height: 70rpx;
			padding: 0 24rpx;
			width: 70rpx;
		}


		.xuanxiang {
			display: flex;
			padding: 12px 0;
			align-items: center;

			navigator {
				width: 460rpx;
				height: 80rpx;
				line-height: 80rpx;
				border: 2rpx solid lightgray;
			}
		}

	}

	.box {
		text-align: center;

		.text {
			font-family: "宋体";
			font-size: 56rpx;
			display: inline-block;
			box-sizing: border-box;
			padding: 40rpx 0;
		}

		.boxs {
			margin-top: 20px;
			display: flex;
			align-items: center;
			justify-content: flex-end;
			width: 80%;
			height: 150rpx;
			margin: auto;
			box-shadow: 4rpx 4rpx 10rpx lightgray;
			background-color: white;

			.bt {
				width: 460rpx;
				height: 120rpx;
				display: inline-block;
				line-height: 120rpx;
				font-size: 56rpx;
				color: black;
			}

			navigator {
				font-size: 24rpx;
				color: lightskyblue;
				padding-right: 20rpx;
			}

			text {
				width: 500rpx;
				height: 100rpx;
			}
		}

		.btss {
			display: inline-flex;
			flex-direction: column;

			text {
				height: 50rpx;
			}

			text:nth-child(even) {
				width: 500rpx;
				white-space: nowrap;
				overflow: hidden;
				text-overflow: ellipsis;
				font-size: 24rpx;
				color: lightgray;
			}
		}

		.box-buttom {
			width: 100%;
			position: absolute;
			display: flex;

			button {
				background-color: lightskyblue;
				color: white;
				width: 40%;
			}
		}

		.cover {
			width: 80%;
			margin: 100rpx auto;

			button {
				color: white;
				border-radius: 23px;
				background-color: #87CEFA;
			}
		}
	}

	.box-content {
		width: 80%;
		margin: auto;
		box-shadow: 4rpx 4rpx 10rpx lightgray;
		background-color: white;
		margin-top: 100rpx;

		text {
			height: 41.6rpx;
			width: 128rpx;
		}

		#box-content1 {
			display: flex;
			align-items: center;
			justify-content: space-around;
			width: 100%;
			height: 100rpx;
			border-bottom: 2rpx solid lightgray;
		}
	}
</style>
