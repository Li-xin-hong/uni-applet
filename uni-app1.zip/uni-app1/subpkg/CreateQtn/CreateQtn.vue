<template>
	<view>
		<view class="box">
			<navigator class="box1" url="/pages/message/message" open-type="switchTab">
				<image src="/static/icon_c83ozse6gdk/icon--my.png" mode="heightFix"></image>
				<text>我的模板</text>
			</navigator>
			<navigator class="box2" url="/subpkg/CreateQtn-kb/CreateQtn-kb">
				<image src="/static/icon_c83ozse6gdk/icon-.png" mode="heightFix"></image>
				<text>空白问卷</text>
			</navigator>
			<navigator class="box3" v-for="(item,index) in list" :key="item.id"
				:url="'/subpkg/Casequestionnaire/Casequestionnaire?title='+	item.name">
				
				<image src="../../static/fenlei.png" mode="heightFix"></image>
				<text>{{item.name}}</text>
			</navigator>
			<!-- 抛弃掉的样式 -->
			<!-- 	<navigator class="box4" url="/subpkg/Casequestionnaire/Casequestionnaire?title=健康测评问卷">
				<image src="/static/icon_c83ozse6gdk/jiankangceping.png" mode="heightFix"></image>
				<text>健康测评问卷</text>
			</navigator>
			<navigator class="box5" url="/subpkg/Casequestionnaire/Casequestionnaire?title=市场调研问卷">
				<image src="/static/icon_c83ozse6gdk/xingtuxuetang-tiaoyan-.png" mode="heightFix"></image>
				<text>市场调研问卷</text>
			</navigator>
			<navigator class="box6" url="/subpkg/Casequestionnaire/Casequestionnaire?title=美食问卷">
				<image src="/static/icon_c83ozse6gdk/meishi.png" mode="heightFix"></image>
				<text>美食问卷</text>
			</navigator>
			<navigator class="box7" url="/subpkg/Casequestionnaire/Casequestionnaire?title=疫情情况问卷">
				<image src="/static/icon_c83ozse6gdk/yiqingtianbao.png" mode="heightFix"></image>
				<text>疫情情况问卷</text>
			</navigator>
			<navigator class="box8" url="/subpkg/Casequestionnaire/Casequestionnaire?title=投票问卷">
				<image src="/static/icon_c83ozse6gdk/navicon-tp.png" mode="heightFix"></image>
				<text>投票问卷</text>
			</navigator>
			<navigator class="box9" url="/subpkg/Casequestionnaire/Casequestionnaire?title=随机问卷">
				<image src="/static/icon_c83ozse6gdk/daibanshixiang.png" mode="heightFix"></image>
				<text>随机问卷</text>
			</navigator> -->
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				list: []
			};
		},
		async created() {
			const {
				data: res
			} = await this.$request({
				url: '/catalogs',
				data: {
					page: 1,
					page_size: 7
				}
			})
			this.list = res.data.list
		}
	}
</script>

<style lang="scss">
	.box {
		width: 100%;
		display: flex;
		flex-wrap: wrap;

		navigator {
			display: flex;
			height: 270rpx;
			justify-content: center;
			align-items: center;
			flex-direction: column;
			width: 32.8%;
			border: 2rpx solid lightgray;

			image {
				height: 100rpx;
				margin-bottom: 16rpx;
			}
		}

		.box3 {
			text {
				width: 128rpx;
				white-space: nowrap;
				overflow: hidden;
				text-overflow: ellipsis;
				text-align: center;
			}
		}
	}
</style>
