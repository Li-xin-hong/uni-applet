<template>
	<!-- 	问卷作答页面 -->
	<view>
		<!-- 问卷头部区域 -->
		<view class="top">
			<text>{{name}}</text>
			<image class="collect" :src="collecturl" mode="widthFix" @click="collect"></image>
			<text style="font-size: 24rpx;color: lightgray;">{{actual_num}}参与</text>
			<image :src="'http://unisurvey.cinnabarpear.top/showFile?name='+cover_url" mode="widthFix"></image>
		</view>
		<!-- .问卷答题区域 -->
		<view class="content">
			<view class="tm" v-for="(item,index) in options" :key="index">
				<text>{{index+1}}.{{item.iptvals}}</text>[{{item.radio}}]
				<radio-group v-if="item.radio=='单选'" @change="radioval($event,item.option_id)">
					<view v-for="items in item.list" :key="items.id">
						<label>
							{{items.id}}.
							<radio :disabled="forbid" :value="items.vals" color="#3A8AFB" />
							<text>{{items.vals}}</text>
						</label>
					</view>
				</radio-group>
				<checkbox-group v-else-if="item.radio=='多选'" @change="checkboxval($event,item.option_id)">
					<view v-for="items in item.list" :key="items.id">
						<label>
							{{items.id}}.
							<checkbox :disabled='forbid' :value="items.vals" color="#3A8AFB" /> {{items.vals}}
						</label>
					</view>
				</checkbox-group>
			</view>
		</view>
		<!-- 提交按钮区域 -->
		<button @click="preserve">提交</button>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				question_id: '', //存储当前问卷的ID
				name: '', //题目
				actual_num: '', //参与人数
				cover_url: '', //封面图片地址
				options: [], //存储问卷题目和选项
				list: [], //存储填写后的答案信息
				collecturl: '../../static/aixin (4).png', //存储收藏图片
				collectstatus: false, //记录收藏的状态
				forbid: false, //判断按钮是否禁用
				curRoute: '', //记录上个页面的值
			};
		},
		onLoad(options) {
			this.question_id = options.question_id
			this.request();
		},
		methods: {
			async request() {
				const {
					data: res
				} = await this.$request({
					url: '/answer/question',
					method: 'GET',
					data: {
						question_id: this.question_id
					}
				})
				this.name = res.data.name
				this.actual_num = res.data.actual_num
				this.cover_url = res.data.cover_url
				this.options = res.data.options.map(e => {
					return JSON.parse(e.content)
				})
				res.data.options.forEach((e, a) => {
					this.options[a].option_id = e.option_id
				})
				this.options.forEach(e => {
					if (e.radio == 'true') {
						e.radio = '单选'
					} else if (e.radio == 'false') {
						e.radio = '多选'
					}
				})
				//给list数组存储option_id值
				res.data.options.forEach(e => {
					this.list.push({
						option_id: e.option_id
					})
				})
				// ----------------------------------------------------------------
				//获取页面路径参数
				let routes = getCurrentPages(); // 获取当前打开过的页面路由数组
				if (routes[routes.length - 2] ==
					"undifend") { //判断一下上一个页面是来自于收藏页还是分享页,当来自于分享页时,routes[routes.length - 2]为undifend
					console.log("来自于分享页");
				} else if (routes[routes.length - 2]) {
					let curRoute = routes[routes.length - 2].route //获取上一个页面路由
					this.curRoute = curRoute
					if (curRoute === 'subpkg/Enshrine/Enshrine') {
						this.forbid = true
					}
				}
				//从本地拉取收藏的信息,判断一下进入的问卷是否有被收藏
				let enshrine = uni.getStorageSync('collect')
				if (enshrine) { //当有收藏信息时可以判断是否有本问卷的收藏,如果有需要将收藏图片修改一下
					enshrine.forEach(e => {
						if (e.question_id === this.question_id) {
							this.collectstatus = true
							this.collecturl = '../../static/aixin (5).png'
						}
					})
				}
			},
			radioval(event, id) {
				//单选题存值
				this.list.forEach((e, a) => {
					if (e.option_id === id) {
						const answer = event.detail.value
						this.list[a].answer = answer
					}
				})
			},
			checkboxval(event, id) {
				//多选题存值
				this.list.forEach((e, a) => {
					if (e.option_id === id) {
						const answer = event.detail.value
						this.list[a].answer = answer
					}
				})
			},
			async preserve() {
				if (this.curRoute === 'subpkg/Enshrine/Enshrine') { //判断是否为收藏页面跳过来的,如果是就将不需要判断一定要填写答案
					let coll = uni.getStorageSync('collect')
					if (this.collectstatus) { //判断是否收藏了该问卷true表示收藏了,false表示没有收藏
						let sun = 0; //记录数据里面是否已经有了收藏的question_id
						coll.forEach(e => {
							if (e.question_id === this.question_id) {
								sun = 1;
							}
						})
						if (sun) { //如果sun为1,说明存在收藏的数据,则无需重复添加
							console.log('数据中已有该收藏的信息,无需重复添加');
						} else {
							coll.push({
								question_id: this.question_id,
							})
							uni.setStorageSync('collect', coll)

						}
					} else { //当没有收藏时,要将本来收藏的问卷的收藏数据删除掉
						coll = coll.filter(e => {
							if (e.question_id !== this.question_id) {
								return e
							}
						})
						uni.setStorageSync('collect', coll)
					}
					uni.navigateTo({
						url: '/subpkg/Enshrine/Enshrine'
					})
				} else { //当不是收藏页面跳过来的时候,说明为提交答案页面
					//先判断是否有填答案在提交
					let judge = 1; //设置变量,判断是否要提交答案
					const pd = this.list.map(e => {
						if (!e.answer) { //当answer不存在时,说明没有点击过选项,选项值为空
							return 0
						} else if (e.answer) {
							if (e.answer.length === 0) { //当answer存在时,说明有点击过选项,此时判断answer的长度,为0说明没有选择选项
								return 0
							}
						}
					})
					//判断pd数组中是否有0这个值,有的话说明有选项没填写,此时将judge赋值为0,将不会进行提交答案操作
					for (let i in pd) {
						if (pd[i] === 0) {
							judge = pd[i]
						}
					}
					if (judge && this.question_id) {
						//必须满足提交条件,才可将list数据转化为JSON格式
						this.list = JSON.stringify(this.list)
						const {
							data: res
						} = await this.$request({
							url: '/user/question/answer',
							method: 'POST',
							data: {
								question_id: this.question_id, //问卷的ID
								answers: this.list //提交的问卷答案
							}
						})
						let coll = uni.getStorageSync('collect')
						if (this.collectstatus) { //判断是否收藏了该问卷true表示收藏了,false表示没有收藏
							let sun = 0; //记录数据里面是否已经有了收藏的question_id
							coll.forEach(e => {
								if (e.question_id === this.question_id) {
									sun = 1;
								}
							})
							if (sun) { //如果sun为1,说明存在收藏的数据,则无需重复添加
								console.log('数据中已有该收藏的信息,无需重复添加');
							} else {
								if (coll) { //当Storage里面有收藏数据时,直接在数组后面添加一条新收藏数据即可
									coll.push({
										question_id: this.question_id,
									})
									uni.setStorageSync('collect', coll)
								} else { //当Storage里面没有收藏数据时,新建一个数组,添加第一条收藏数据
									coll = [{
										question_id: this.question_id,
									}]
									uni.setStorageSync('collect', coll)
								}
							}
						} else { //当没有收藏时,要将本来收藏的问卷的收藏数据删除掉
							coll = coll.filter(e => {
								if (e.question_id !== this.question_id) {
									return e
								}
							})
							uni.setStorageSync('collect', coll)
						}
						uni.switchTab({
							url: '/pages/home/home'
						})
						if (res.code !== 200) {
							uni.showToast({
								title: res.msg,
								icon: "none"
							})
						} else if (res.code == 200) { //判断是否已经提交过了
							let partic = uni.getStorageSync('Participation')
							let date = new Date().toISOString().slice(0, 10)
							let h = new Date().getHours()
							let min = new Date().getMinutes()
							let s = new Date().getSeconds()
							if (h < 10) {
								h = "0" + h
							}
							if (min < 10) {
								min = "0" + min
							}
							if (s < 10) {
								s = "0" + s
							}
							let time = date + ' ' + h + ':' + min + ':' + s
							if (partic) {
								partic.push({
									question_id: this.question_id,
									time: time
								})
								uni.setStorageSync('Participation', partic)
							} else {
								partic = [{
									question_id: this.question_id,
									time: time
								}]
								uni.setStorageSync('Participation', partic)
							}
						}
					} else {
						uni.showToast({
							title: '您还有答案未填写,请填写完整',
							icon: "error"
						})
					}
				}

			},
			collect() { //点击收藏的方法
				if (!this.collectstatus) { //默认是false
					this.collecturl = '../../static/aixin (5).png'
					this.collectstatus = true
				} else {
					this.collecturl = '../../static/aixin (4).png'
					this.collectstatus = false
				}
			},

		},
	}
</script>

<style lang="scss">
	.collect {
		width: 100rpx;
		position: absolute;
		right: 0rpx;
	}

	.top {
		position: relative;
		width: 94%;
		height: 500rpx;
		margin: 20rpx;
		background-color: white;
		display: flex;
		flex-direction: column;

		text {
			margin: 10rpx 30rpx;
		}

		image {
			margin: 10rpx 30rpx;
		}
	}

	.content {
		width: 94%;
		background-color: white;
		margin: 100rpx 20rpx;


		.tm {
			width: 100%;
			border-bottom: 1px solid lightgray;

			view {
				margin: 8rpx;
			}
		}
	}

	.box {
		background-color: #3A8AFB;
		color: white;
	}

	button {
		width: 80%;
		margin: auto;
		background-color: #3A8AFB;
		color: white;
	}
</style>
