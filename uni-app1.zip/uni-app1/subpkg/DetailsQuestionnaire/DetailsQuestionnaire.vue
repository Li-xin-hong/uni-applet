<template>
	<!-- //已创建的问卷详情页面 -->
	<view>
		<!-- 问卷详情头部区域 -->
		<view class="top">
			<view class="top-box1">
				{{name}}
			</view>
			<view class="top-box2">
				<!--  第一层进度条的背景色  -->
				<view class="strip">
					<!-- 第二层进度条的颜色 -->
					<view class="blue" :style="'width:'+info.progress+'%'">
						<!-- （进度条显示的图片  样式：根据父元素进行相对定位 ，本身绝对定位 ） -->
						<image src="../../static/icon_j2n4y6115i/niuniu.png" class="proImg"
							:style="'left:'+parseInt(info.progress-5)+'%'">
						</image>
					</view>
				</view>
			</view>
			<view class="top-box3">
				<text>填写:{{actual_num}}/{{expected_num}}</text>
				<text>{{info.progress}}%</text>
			</view>
			<!-- 头部功能区域 -->
			<view class="top-box4">
				<button open-type="share" plain="true" :data-question_id="question_id">
					<image src="../../static/icon_j2n4y6115i/icon--share.png">
					</image>
					<text>分享问卷</text>
				</button>
				<view @click="update">
					<image src="../../static/icon_j2n4y6115i/xiugai.png">
						<text>修改问卷</text>
					</image>
				</view>
				<view @click="watch">
					<image :src="url" :style="sty" mode="widthFix">
						<text>查看结果</text>
					</image>
				</view>
				<view @click="remove">
					<image src="../../static/shanchu (2).png">
						<text>删除问卷</text>
					</image>
				</view>
			</view>
		</view>
		<!-- 	问卷详情内容主体区域 -->
		<view class="content">
			<view class="showone" v-show="ok">
				<view class="choice" v-for="(item,index) in content" :key="index">
					<text>{{parseInt(index+1)}}.{{item.content.iptvals}}【{{item.content.radio}}】</text>
					<view class="result">
						<view class="results" v-for="items in content[index].content.list" :key="items.id"
							:style="items.color">
							{{items.id}}.{{items.vals}}
						</view>
					</view>
				</view>
			</view>
			<!-- 问卷统计结果详细 默认不展示-->
			<view class="showtwo" v-show="oks">
				<view class="content-box1" v-for="(item,index) in content" :key="index">
					<text class="tx"
						style="margin: 30rpx 0 0 20rpx;">{{parseInt(index+1)}}.{{item.content.iptvals}}【{{item.content.radio}}】</text>
					<view class="option">
						<view class="option-b1">
							<text>选项</text>
							<text>小计</text>
							<text>比例</text>
						</view>
						<view class="option-b2" v-for="(items,index) in content[index].content.list" :key="items.id">
							<text>{{items.vals}}</text>
							<text>{{items.subtotal}}</text>
							<text>{{items.percentum}}%</text>
						</view>
					</view>
					<text style="margin-bottom: 30px;position: relative;left: 64rpx;"
						class="tx">本题有效填写人次:{{item.sum}}</text>
				</view>
			</view>
		</view>
	</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				name: '', //问卷标题
				question_id: '', //记录问卷ID值
				info: { //背景蓝色的宽度
					progress: 0,
				},
				expected_num: '', //理想人数
				actual_num: '', //实际人数
				url: "../../static/icon_j2n4y6115i/guanbichakan.png", //查看结果的图片
				ok: true, //默认显示
				oks: false, //默认不显示
				content: [], //用来记录题目和选项的数据
				sty: 'width: 88rpx;', //记录查看结果图片的样式
				colors: 'background-color: #169BD5;', //动态添加背景色

			}
		},
		async onLoad(options) {
			this.question_id = options.question_id //获取页面参数中的question_id,赋值给data中的ID变量
			//获取页面路径参数
			let routes = getCurrentPages(); // 获取当前打开过的页面路由数组

			let curRoute = routes[routes.length - 2].route //获取上一个页面路由

			const {
				data: res
			} = await this.$request({
				url: '/user/options',
				method: 'GET',
				data: {
					question_id: this.question_id
				}
			})
			this.name = res.data.name //问卷标题
			this.expected_num = res.data.expected_num //理想人数
			this.actual_num = res.data.actual_num //实际参与人数
			this.content = res.data.options //存储问卷题目和选项信息
			this.content.forEach(e => {
				e.content = JSON.parse(e.content) //将content数据改为对象形式
				if (e.content.radio == 'true') { //将radio的true和false改为单选或者多选
					e.content.radio = "单选"
				} else {
					e.content.radio = "多选"
				}
				let sum = 0;
				e.content.list.forEach((es, a) => { //循环用答案与选项作对比有的计数上加1
					es.subtotal = 0 //记录单个选项的答题人数
					es.percentum = 0; //记录单个选项答题数占这题总答题数的百分比number类型
					if (e.content.radio === '单选') {
						e.answers.forEach(esx => {
							if (esx.answer == es.vals) {
								es.subtotal = esx.nums;
								if (curRoute === 'subpkg/Participation /Participation ') {
									es.color = this.colors
								}
							}
						})
					} else if (e.content.radio === '多选') {
						e.answers.forEach(ess => {
							const val = JSON.parse(ess.answer)
							for (let i of val) {
								if (i == es.vals) {
									es.subtotal++;
									if (curRoute === 'subpkg/Participation /Participation ') {
										es.color = this.colors
									}
								}
							}
						})
					}
					sum += es.subtotal //计算每个选项所填写的答案总和
				})
				e.sum = sum //记录每一题的总填写人数
				e.content.list.forEach(t => { //计算出单个选项答题数占这题总答题数的百分比值
					if (sum != 0) { //由于0/0=NaN,1/0=Infinity,0/1=0 所以sum不可以为0
						let ss = `${(t.subtotal / sum) * 100}` //将number类型的百分比值转化为String类型查找是否有小数点
						if (ss.indexOf(".") != -1) { //判断是否有小数点返回不同的百分比值
							ss = +(ss);
							t.percentum = ss.toFixed(2) //若有小数只取到小数点后两位
						} else {
							t.percentum = parseInt(ss) //若无小数原值赋值
						}
					}
				})
			})
		},
		methods: {
			onShareAppMessage(e) { //分享问卷的方法
				if (e.from === 'button') {
					const question_id = e.target.dataset.question_id;
					return {
						title: `${this.name}`,
						path: `/subpkg/Details/Details?question_id=${question_id}`,
						imageUrl: '../../static/xinxi-.png'
					}
				} else {
					return {
						title: `${this.name}`,
						path: `/subpkg/Details/Details?question_id=${this.question_id}`,
						imageUrl: '../../static/xinxi-.png'
					}
				}
			},
			update() { //跳转到修改页面
				uni.navigateTo({
					url: `/subpkg/Update/Update?question_id=${this.question_id}`
				})
			},
			watch() { //查看统计结果方法
				if (this.ok) {
					this.ok = false
					this.oks = true
					this.url = '../../static/icon_j2n4y6115i/chakan.png'
					this.sty = "width:48rpx"
				} else {
					this.ok = true
					this.oks = false
					this.url = '../../static/icon_j2n4y6115i/guanbichakan.png'
					this.sty = "width:88rpx"
				}

			},
			remove() { //删除问卷的方法
				console.log(this.question_id);
				uni.showModal({
					title: '提示',
					content: "您确定要删除此问卷吗？",
					success: e => {
						if (e.confirm) {
							this.$request({
								url: "/user/question",
								method: 'DELETE',
								data: {
									question_id: this.question_id
								}
							})
							uni.navigateBack();
						}
					}
				})
			},
		},
		computed: { //计算属性
			push() {
				//实际人数/理想人数 计算出问卷的答题详细百分比
				this.info.progress = +(this.actual_num / this.expected_num) * 100
				return this.info.progress
			}
		}
	}
</script>

<style lang="scss">
	page {
		background-color: lightgray;
	}

	.top {
		background-color: white;
		width: 90%;
		margin: 30rpx auto;
		height: 320rpx;
		border: 1rpx solid white;
	}

	.top-box1 {
		margin-top: 20rpx;
		width: 100%;
		text-align: center;
		font-weight: bold;
	}

	.top-box2 {
		display: flex;
		justify-content: center;
		margin: 20rpx 0;

		.strip {
			/* 父元素相对定位 */
			position: relative;
			width: 360rpx;
			height: 12rpx;
			color: rgba(80, 80, 80, 1);
			background-color: lightgray;
			border-radius: 7rpx;
			font-size: 28rpx;
			line-height: 150%;
			text-align: center;
		}

		.blue {
			height: 12rpx;
			color: rgba(80, 80, 80, 1);
			background-color: #169BD5;
			border-radius: 7rpx;
			font-size: 28rpx;
			line-height: 150%;
			text-align: center;
		}

		.proImg {
			width: 84rpx;
			height: 76rpx;
			/* 子元素绝对定位   */
			position: absolute;
			/* 定位方向：属性值 */
			top: -30rpx
		}
	}

	.top-box3 {
		font-size: 24rpx;
		color: lightgray;
		width: 360rpx;
		display: flex;
		margin: auto;
		justify-content: space-between;

	}

	.top-box4 {
		width: 100%;
		display: flex;
		justify-content: space-evenly;
		margin-top: 40rpx;
		color: #36A6E0;
		font-size: 30rpx;

		view {
			display: inline-flex;
			align-items: center;
			flex-direction: column;

			image {
				width: 50rpx;
				height: 50rpx;
			}
		}

		button {
			display: inline-flex;
			align-items: center;
			flex-direction: column;
			color: #36A6E0;
			font-size: 30rpx;
			margin: 0;
			padding: 0;
			line-height: 40rpx;
			border: 1rpx solid white;

			image {
				width: 50rpx;
				height: 50rpx;
			}
		}
	}


	//题目和选项的样式

	//选项的样式
	.choice {
		width: 100%;

		text {
			margin: 30rpx 0 0 20rpx;
			display: inline-block;
			width: 80%;
			height: 30rpx;
			line-height: 30rpx;
		}

		.result {
			width: 90%;
			margin: 20rpx auto;
			border: 1rpx solid white;

			.results {
				width: 100%;
				height: 50rpx;
				line-height: 50rpx;
			}
		}
	}




	.content {
		//问卷统计结果详细样式
		width: 90%;
		border: 1rpx solid white;
		background-color: white;
		margin: 50rpx auto;

		.tx {
			display: inline-block;
			width: 80%;
			height: 30rpx;
			line-height: 30rpx;
		}

		.content-box1 {
			width: 100%;

			.option {
				width: 80%;
				margin: 20rpx auto;

				view {
					display: flex;
					border-bottom: 1rpx solid #C9C9C9;
					border-left: 1rpx solid #C9C9C9;
					border-right: 1rpx solid #C9C9C9;

					text {
						text-align: center;
						line-height: 50rpx;
						width: 33.3%;
						height: 50rpx;
					}
				}

				.option-b1 {
					color: white;
					background-color: #169BD6;
				}
			}

		}
	}
</style>
