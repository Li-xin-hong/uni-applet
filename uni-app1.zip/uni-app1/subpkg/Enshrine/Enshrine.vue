<template>
	<view>
		<view class="top">
			<view class="template" v-for="(item,index) in list" :key="item.question_id" @click="skip(item.question_id)">
				<image :src="'http://unisurvey.cinnabarpear.top/showFile?name='+item.res.cover_url"></image>
				<text style="color: lightgray;font-size: 24rpx;text-align: end;text-align: right;
    width: 86%;margin: 4rpx 0;">参与人数{{item.res.actual_num}}</text>
				<text>{{item.res.name}}</text>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				list: []
			};
		},
		onShow() {
			this.enshrine() //获取我所收藏的问卷
		},
		methods: {
			async enshrine() {
				let list = uni.getStorageSync('collect')

				//由于存提交问卷的信息数据时s,是在数组的末尾添加,所以取出时先做一下数组的反转再遍历展示数组
				for (var i = 0; i < list.length / 2; i++) {
					var temp = list[i];
					list[i] = list[list.length - 1 - i];
					list[list.length - 1 - i] = temp;
				}
				for (let i of list) {
					const {
						data: res
					} = await this.$request({
						url: '/user/options',
						method: 'GET',
						data: {
							question_id: i.question_id
						}
					})
					i.res = res.data
				}
				this.list = list

			},
			skip(id) {
				uni.navigateTo({
					url: `/subpkg/Details/Details?question_id=${id}`
				})
			}
		}
	}
</script>

<style lang="scss">
	.top {
		display: flex;
		flex-wrap: wrap;
		justify-content: space-between;
		width: 100%;

		.template {
			display: flex;
			width: 32%;
			height: 300rpx;
			flex-direction: column;
			justify-content: center;
			align-items: center;

			image {
				width: 200rpx;
				height: 200rpx;
			}
		}
	}
</style>
