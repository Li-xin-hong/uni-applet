<template>
	<view>
		<view class="top">
			<view class="template" v-for="(item,index) in list" :key="item.questionId" @click="skip(item.questionId)">
				<image :src="'http://unisurvey.cinnabarpear.top/showFile?name='+item.cover_url"></image>
				<text style="color: lightgray;font-size: 24rpx;text-align: end;text-align: right;
    width: 86%;margin: 4rpx 0;">参与人数{{item.actual_num}}</text>
				<text>{{item.name}}</text>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				list: []
			};
		},
		async onShow() {
			const {
				data: res
			} = await this.$request({
				url: '/user/questions',
				methods: 'GET',
				data: {
					page: 1,
					page_size: 12
				}
			})
			this.list = res.data.list
		},
		methods: {
			skip(id) {
				uni.navigateTo({
					url: `/subpkg/DetailsQuestionnaire/DetailsQuestionnaire?question_id=${id}`
				})
			}
		}
	}
</script>

<style lang="scss">
	.top {
		display: flex;
		flex-wrap: wrap;
		justify-content: space-between;
		width: 100%;

		.template {
			display: flex;
			width: 32%;
			height: 300rpx;
			flex-direction: column;
			justify-content: center;
			align-items: center;

			image {
				width: 200rpx;
				height: 200rpx;
			}
		}
	}
</style>
