<template>
	<view>
		<!-- 我参与的页面 -->
		<!-- 参与排版页面 -->
		<view class="content">
			<view class="box" v-for="(item,index) in list" :key="index" @click="skip(item.question_id)">
				<text>【{{item.res.status}}问卷】{{item.res.name}}</text>
				<view class="main-content ">
					<view>参与问卷</view>
					<view>参与人数:{{item.res.actual_num}}</view>
					<view>{{item.time}}</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				list: [] //存储从Storage拿到的提交的问卷信息数据
			};
		},
		onShow() {
			this.request(); //哪些问卷参与过的数据
		},
		methods: {
			async request() { //从本地找到提交的问卷数据
				let list = uni.getStorageSync('Participation')
				//由于存提交问卷的信息数据时s,是在数组的末尾添加,所以取出时先做一下数组的反转再遍历展示数组
				for (var i = 0; i < list.length / 2; i++) {
					var temp = list[i];
					list[i] = list[list.length - 1 - i];
					list[list.length - 1 - i] = temp;
				}
				for (let i of list) {
					const {
						data: res
					} = await this.$request({
						url: '/user/options',
						method: 'GET',
						data: {
							question_id: i.question_id
						}
					})
					if (res.data.status === 'doing') {
						res.data.status = '已开始'
					} else if (res.data.status === 'unstart') {
						res.data.status = '未开始'
					} else if (res.data.status === 'done') {
						res.data.status = '已结束'
					}
					i.res = res.data
				}
				this.list = list
			},
			skip(id) {
				uni.navigateTo({
					url: `/subpkg/DetailsQuestionnaire/DetailsQuestionnaire?question_id=${id}`
				})
			},
		}
	}
</script>

<style lang="scss">
	.content {
		width: 100%;
	}

	.box {
		width: 100%;
		height: 160rpx;
		border-bottom: 1rpx solid lightgray;

		text {
			display: inline-block;
			width: 100%;
			text-align: center;
			font-weight: bold;
			height: 100rpx;
			line-height: 100rpx;
		}

		.main-content {
			display: flex;
			width: 100%;
			justify-content: space-around;
			font-size: 24rpx;
			color: lightgray;
		}
	}
</style>
