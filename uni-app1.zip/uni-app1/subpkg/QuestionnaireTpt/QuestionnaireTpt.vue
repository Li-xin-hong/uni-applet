<template>
	<view>
		<view class="top">
			<input type="text" placeholder="请输入关键字,搜索问卷模板~" @confirm="inputConfirm">
			<text>搜索</text>
		</view>
		<!-- 问卷模板区域 -->
		<view class=" TemplateContent">
			<view class="box1" v-for="(item,index) in list" :key="item.questionId" @click="skip(item.questionId)">
				<image :src="'http://unisurvey.cinnabarpear.top/showFile?name='+item.cover_url"></image>
				<view class="box2">
					<view class="box2-left">
						{{item.authority}}
					</view>
					<view class="box2-right">
						{{item.actual_num}}人参与
					</view>
				</view>
				<text>{{item.name}}</text>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				list: [] //已经创建好的问卷当做官方示例模板
			};
		},
		async created() {
			const {
				data: res
			} = await this.$request({
				url: '/user/questions',
				method: 'GET',
			})
			console.log(res.data.list);
			this.list = res.data.list
			this.list.forEach(e => {
				if (e.authority === 'public') {
					e.authority = '公开问卷'
				} else if (e.authority === 'private') {
					e.authority = '私有问卷'
				}
			})

		},
		methods: {
			skip(id) {
				uni.navigateTo({
					url: `/subpkg/Details/Details?question_id=${id}`
				})
			},
			inputConfirm(e) {
				console.log(e.detail.value);
			}
		}
	}
</script>

<style lang="scss">
	.top {
		margin-top: 20rpx;
		display: flex;
		justify-content: center;
		align-items: center;
		font-size: 24rpx;

		input {
			width: 80%;
			background-color: lightgray;
			text-align: center;
			border-radius: 52rpx;
			height: 52rpx;
		}

		text {
			margin-left: 10rpx;
		}
	}

	.TemplateContent {
		display: flex;
		width: 100%;
		flex-wrap: wrap;
		justify-content: space-between;

		.box1 {
			display: flex;
			flex-direction: column;
			justify-content: center;
			align-items: center;
			width: 49.8%;
			height: 400rpx;
			border-bottom: 2rpx solid lightgray;

			image {
				width: 280rpx;
				height: 240rpx;
			}

			text {
				font-size: 24rpx;
				white-space: pre-wrap;
				width: 75%;
				letter-spacing: 4rpx;
				font-weight: bold;
				box-sizing: border-box;
				padding-top: 20rpx;
				padding-left: 8rpx;
			}

			.box2 {
				width: 70%;
				display: flex;
				font-size: 20rpx;
				justify-content: space-between;
				color: #C8CAC5;
				padding-top: 10rpx;

				.box2-left {
					width: 50%;
				}

				.box2-right {
					width: 50%;
					text-align: end;
				}
			}
		}

		.box1:nth-of-type(odd) {
			border-right: 2rpx solid lightgray;
		}
	}
</style>
