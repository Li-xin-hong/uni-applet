<template>
	<view class="box">
		<form>
			<text>标题</text>
			<input type="text" placeholder="请输入标题" v-model="name">
			<text>问卷描述</text>
			<textarea placeholder="请输入问卷描述的内容" v-model="iptval1"></textarea>
			<button plain="true" @click="getadd">保存</button>
		</form>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				//存储input的value值
				name: '',
				iptval1: '', //存储问卷描述的内容
				question_id: '',
			};
		},
		onLoad(options) {
			this.name = options.name
			this.iptval1 = options.iptval1
			this.question_id = options.id
		},
		methods: {
			getadd() {
				if (this.iptval !== '') {
					uni.setStorageSync('name', this.name)
					uni.setStorageSync('iptval1', this.iptval1)
					uni.navigateBack()
				} else {
					uni.showToast({
						title: '标题不能为空',
						icon: "error"
					})
				}
			}
		}
	}
</script>

<style lang="scss">
	page {
		height: 100%;
		background-color: #52A8FB;
		position: relative;
	}

	.box {
		width: 100%;
		text-align: center;

		text {
			position: relative;
			top: 60rpx;
			font-size: 56rpx;
			color: white;
		}

		input {
			margin: 160rpx auto 0 auto;
			width: 560rpx;
			height: 80rpx;
			border: 2rpx solid lightskyblue;
		}

		textarea {
			margin: 160rpx auto 0 auto;
			width: 560rpx;
			height: 350rpx;
			border: 2rpx solid lightskyblue;
		}

		button {
			position: absolute;
			bottom: 0px;
			border: 1px solid white;
			width: 100%;
			color: white;
		}
	}
</style>
