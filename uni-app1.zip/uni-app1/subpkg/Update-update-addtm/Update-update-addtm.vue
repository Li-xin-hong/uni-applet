<template>
	<view>
		<view class="box">
			<text class="text">标题</text>
			<view class="boxs box-top">
				<input type="text" placeholder="请输入题目标题" v-model="iptvals">
			</view>
			<text class="text">选项</text>
			<view class="box-content">
				<view class="box1">
					<view class="xuanxiang" v-for="(item,index) in list" :key="item.id">
						<image src="../../static/shanchu.png" mode="heightFix" @click="dianji(item.id)"></image>
						<input type="text" placeholder="请输入选项内容" v-model="item.vals">
					</view>
				</view>
				<view class="box2">
					<text @click="add">添加选项</text>
				</view>
			</view>
			<view class="box-content1">
				<view class="box-select" id="box-content1">
					<text>题型切换</text>
					<view style="width: 55px;height: 18px;display: flex;" @click="radios">
						<text v-if="radio=='true'">单选</text>
						<text v-else-if="radio=='false'">多选</text>
						<image :src="srcurl" mode="widthFix"></image>
					</view>
				</view>
			</view>
			<!-- 保存按钮区域 -->
			<button @click="action">保存</button>
		</view>
	</view>
</template>

<script>
	import mycheckbox from '@/components/CreateQtn/CreateQtn.vue'
	export default {
		data() {
			return {
				iptvals: '', //双向绑定存储标题input的value值
				srcurl: '/static/xiajiantou.png', //上下箭头图表路径
				radio: "true", //存储单选多选的状态来现显示与隐藏
				list: [{
					id: 1,
					vals: '' //双向绑定存储标题内容input的value值
				}, {
					id: 2,
					vals: ''
				}, {
					id: 3,
					vals: ''
				}, {
					id: 4,
					vals: ''
				}], //存储选项标签
				id: 0, //最后一个id值
				titleid: '' //记录前面页面传过来的ID
			};
		},
		onLoad(options) {
			this.titleid = options.id
		},
		onUnload() {
			uni.$off("datax")
		},

		methods: {
			dianji(id) {
				this.list = this.list.filter(e => {
					if (e.id != id) {
						return e
					}
				})
			},
			add() {
				this.id = this.list[this.list.length - 1].id
				this.id++;
				this.list.push({
					id: this.id,
					vals: '',
				});
			},
			radios() {
				if (this.radio == 'true') {
					this.radio = "false"
					this.srcurl = '/static/shangjiantou.png'
				} else if (this.radio == "false") {
					this.radio = "true"
					this.srcurl = '/static/xiajiantou.png'
				}
			},
			action() {
				//传数据给父页面
				uni.$emit('datax', {
					iptvals: this.iptvals, //传题目标题的数据
					list: this.list, //传题目选项的数据(数组)
					radio: this.radio, //传题目单选多选的状态的数据
					titleid: this.titleid

				});
				const res = this.list.filter((e) => {
					if (e.vals === '') {
						return e
					}
				})
				// 跳转到上一页
				if (this.iptval != '' && res.length < 1) {
					uni.navigateBack();
				} else {
					uni.showToast({
						title: "您有信息未填写",
						icon: 'error'
					})
				}
			},
		},
		components: {
			mycheckbox
		}
	}
</script>

<style lang="scss">
	.box {
		text-align: center;

		.text {
			font-family: "宋体";
			font-size: 56rpx;
			display: inline-block;
			box-sizing: border-box;
			padding: 40rpx 0;
		}

		.boxs {
			margin-top: 20px;
			display: flex;
			align-items: center;
			justify-content: center;
			width: 80%;
			height: 150rpx;
			margin: auto;
			box-shadow: 4rpx 4rpx 10rpx lightgray;
			background-color: white;

			text {
				width: 500rpx;
				height: 100rpx;
			}

			input {
				width: 520rpx;
				height: 80rpx;
				border: 2rpx solid lightgray;
			}

		}

		image {
			height: 70rpx;
			padding: 0 24rpx;
		}

		.xuanxiang {
			display: flex;
			padding: 12px 0;
			align-items: center;
		}

		.box-content {
			margin-top: 20px;
			width: 80%;
			margin: auto;
			box-shadow: 4rpx 4rpx 10rpx lightgray;
			background-color: white;

			input {
				width: 460rpx;
				height: 80rpx;
				border: 2rpx solid lightgray;
			}
		}

		.box2 {
			display: flex;
			justify-content: center;
			align-items: flex-start;
			height: 70rpx;
			font-size: 24rpx;
			color: lightskyblue;
		}

		.box-content1 {
			width: 80%;
			margin: auto;
			box-shadow: 4rpx 4rpx 10rpx lightgray;
			background-color: white;
			margin-top: 100rpx;

			text {
				height: 41.6rpx;
				width: 128rpx;
			}

			image {
				width: 70rpx;
				padding: 0;
				position: relative;
				left: 30rpx;
			}

			#box-content1 {
				display: flex;
				align-items: center;
				justify-content: space-around;
				width: 100%;
				height: 100rpx;
				border-bottom: 2rpx solid lightgray;
			}

			//控制单选多选
			.danyuankuang {
				position: relative;
				left: 20rpx;
			}
		}

		button {
			margin-top: 200rpx;
			background-color: #52A8FB;
			width: 100%;
			color: white;
		}

	}
</style>
