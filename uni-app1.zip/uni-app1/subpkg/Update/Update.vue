<template>
	<view>
		<view class="box">
			<text class="text">标题</text>
			<view class="boxs box-top">
				<view class="btss">
					<text>{{name}}</text>
					<text>{{iptval1}}</text>
				</view>
				<navigator url="#" @click="Goto">编辑</navigator>
			</view>
			<text class="text">问题</text>
			<view class="xs">
				<view class="xuanxiang" v-for="(item,index) in list" :key="item.id">
					<image src="../../static/shanchu.png" mode="widthFix" @click="remove(item.id)"></image>
					<text class="bt" @click="skip(item.id)">
						{{item.iptvals}}
					</text>
				</view>
				<view>
					<view style="font-size: 24rpx;color: lightskyblue;height: 60rpx;" @click="add">添加问题
					</view>
				</view>
			</view>
			<!-- ------------------------------------------------------------------------------ -->
			<view class="box-content">
				<view class="box-kg" id="box-content1">
					<text>题目必答</text>
					<mycheckbox :checked="checekval" @click.native="change(1)" v-if="control"></mycheckbox>
				</view>
				<view class="box-kg" id="box-content1">
					<text>是否公开</text>
					<mycheckbox :checked="checekval" @click.native="change(2)" v-if="control"></mycheckbox>
				</view>
				<view class="box-kg" id="box-content1">
					<text>分类</text>
					<picker mode="selector" :range="arrays" :value="index" range-key="name" @change="classifychange">
						<view>{{arrays[index].name}}</view>
					</picker>
				</view>
				<view class="box-kg" id="box-content1">
					<uni-section :title="'日期时间范围用法：' + '[' + datetimerange + ']' " type="line"></uni-section>
					<view class="example-body">
						<uni-datetime-picker v-model="datetimerange" type="datetimerange" rangeSeparator="至" />
					</view>
				</view>
				<view class="box-kg" id="box-content1" @click="fours">
					<text>理想人数</text>
					<input type="number" placeholder="请输入理想的人数" v-model="expected_num" style="width: 100rpx;"
						:focus="IfFocus">
				</view>
			</view>
			<!-- 获取问卷调查封面图片区域 -->
			<view class="cover">
				<image :src="'http://unisurvey.cinnabarpear.top/showFile?name='+cover_url" mode="widthFix" style="margin-bottom: 50rpx;
    width: 500rpx;"></image>
				<button @click="cover">选择封面图片</button>
			</view>
			<view class="box-buttom">
				<button @click="preserve">保存问卷</button><button>发布问卷</button>
			</view>
		</view>

	</view>
</template>

<script>
	import mycheckbox from '@/components/CreateQtn/CreateQtn.vue'
	export default {
		data() {
			return {
				//存储获取到的页面参数,并渲染到页面上
				question_id: '', //存储页面ID值通过这个ID来请求问卷信息
				control: false, //默认开关按钮不展示
				name: '问卷标题',
				iptval1: '为了给您提供更好的服务,希望您能抽出几分钟时间,将您的感受和建议告诉我们,我们非常重视每位用户的宝贵意见,期待您的参与！现在我们就马上开始吧！', //问卷描述
				Upoptions: '', //存储问卷信息（题目及其选项的数据）
				checekval: true, //存储开关按钮的开关值(记录问卷是否否是必填项)
				datetimerange: [], //选择问卷的开始和结束的时间
				arrays: [], //存储选择的分类
				index: '', //默认展示的选择分类的下标
				numbers: '', //理想人数
				switchval: '', //存储是否公开的值
				list: [], //展示页面
				catalog_id: '', //存储catalog_id来判断要默认展示哪个分类
				expected_num: '', //存储理想人数的数量
				cover_url: '', //存储封面图片的地址
				IfFocus: false, //控制理想人数里面的聚焦情况
				id: 0, //记录list数组的最后一个ID,用于后续的增删
				ischeck: '',
				obj: [] //存储修改完过后的所有需要提交的content数据信息
			};
		},
		onLoad(options) {
			const page = getCurrentPages()
			const pages = page[page.length - 2]
			//默认渲染的方法
			this.amend(options, pages.route);
		},
		onShow() {
			this.headline();
			this.list.forEach(e => {
				if (typeof e.list == 'string') {
					e.list = JSON.parse(e.list)
				}
			})
			this.Optiondatas()
			this.Optiondata();
		},
		onHide() {
			if (this.data == 'skip') {
				uni.$off("datax")
			} else {
				uni.$off("datas")
			}
		},
		methods: {
			async amend(options, pages) { //渲染时所需要用到方法
				// 通过options.question_id获取需要请求的问卷详细信息
				this.question_id = options.question_id //存储问卷请求所需要的ID
				const {
					data: res
				} = await this.$request({
					url: "/answer/question",
					data: {
						question_id: options.question_id
					}
				})
				if (res.data.status === 'doing') {
					uni.navigateBack()
					uni.showToast({
						title: '已开始的问卷不可以修改',
						icon: 'none'
					})
				}
				if (pages == 'subpkg/Icreated/Icreated') {
					this.name = res.data.name //存储问卷题目	
				}
				this.catalog_id = res.data.catalog_id //存储分类的ID
				this.Upoptions = res.data.options.map(e => {
					return JSON.parse(e.content)
				}) //通过遍历将JSON格式的问卷详情信息转化为数组形式
				this.list = this.Upoptions //存储问卷详情信息
				this.list = this.list.map((e, a) => {
					e.id = res.data.options[a].option_id
					return e
				})
				//问卷公开还是私密
				this.checekval = this.list[0].checekval
				console.log(res.data.authority);
				if (res.data.authority == 'public') {
					this.switchval = true
				} else if (res.data.authority == 'private') {
					this.switchval = false
				}
				this.control = true
				//问卷开始结束时间
				this.datetimerange[0] = res.data.create_date
				this.datetimerange[1] = res.data.end_date
				//问卷理想人数
				this.expected_num = res.data.expected_num
				this.cover_url = res.data.cover_url
				// -------------------------------------------------------------------
				// 请求分类列表
				const {
					data: ress
				} = await this.$request({
					url: '/catalogs',
					data: {
						page: 1,
						page_size: 7
					}
				})
				//存储分类列表
				this.arrays = ress.data.list
				//获取根据分类ID默认的下标index值
				for (let i in this.arrays) {
					if (this.arrays[i].id == this.catalog_id) {
						this.index = i
					}
				}
				//获取到问卷数据,渲染至页面展示
			},
			headline() { //修改问卷标题和问卷详细的方法
				this.name = uni.getStorageSync('name');
				this.iptval1 = uni.getStorageSync('iptval1')
			},
			Optiondatas() { //添加新题目的方法
				uni.$on('datax', e => {
					this.list.push({
						id: +e.titleid,
						checekval: true,
						iptvals: e.iptvals,
						radio: e.radio,
						list: e.list
					})
				})
			},
			Optiondata() { //修改原来题目的数据的方法
				uni.$on('datas', (event) => {
					this.list.forEach(e => {
						if (e.id == event.titleid) {
							e.iptvals = event.iptvals; //修改题目题目头
							e.radio = event.radio; //修改题目单选还是多选
							e.list = event.list //修改题目list选项
						}
					})
				})
			},
			fours() { //理想人数的view聚焦方法
				this.IfFocus = true
			},
			Goto() { //跳转到问卷标题和问卷详细页的方法
				uni.navigateTo({
					url: `/subpkg/Update-bj/Update-bj?name=${this.name}&iptval1=${this.iptval1}&id=${this.question_id}`
				})
			},
			skip(id) { //跳转到修改题目和选项的页面方法
				this.data = 'skip'
				const list = this.list.filter(e => { //判断一下点击了哪一个题目,将改题目对应的数据传输给子页面
					if (e.id == id) {
						return e
					}
				})
				list[0].list = JSON.stringify(list[0].list) //选项数据为数组,不能用url传输,改为JSON格式传输
				uni.navigateTo({
					url: `/subpkg/Update-bj-add/Update-bj-add?id=${id}&iptvals=${list[0].iptvals}&radio=${list[0].radio}&list=${list[0].list}&question_id=${this.question_id}`
				})
			},
			remove(id) { //删除题目的方法
				this.list = this.list.filter(e => {
					if (e.id != id) {
						return e
					}
				})
			},
			add() { //增加新题目的方法
				this.data = 'add'
				if (this.list.length > 0) {
					this.id = this.list[this.list.length - 1].id
					this.id++;
				} else if (this.list.length == 0) {
					this.id++;
				}
				uni.navigateTo({
					url: `/subpkg/Update-update-addtm/Update-update-addtm?id=${this.id}`
				})
			},
			classifychange(e) { //分类的方法
				this.index = e.detail.value //分类列表的下标
				this.catalog_id = this.arrays[this.index].id //存储分类列表的ID	
			},
			change(e) { //按钮选项控制的方法
				if (e === 1) {
					if (this.checekval) {
						this.checekval = false
					} else if (!this.checekval) {
						this.checekval = true
					}
				} else if (e === 2) {
					if (this.switchval) {
						this.switchval = false
					} else if (!this.switchval) {
						this.switchval = true
					}
				}
			},
			async preserve() { //提交修改好的数据的方法
				if (this.switchval) {
					this.switchval = "public"
				} else {
					this.switchval = "private"
				}
				this.list.forEach(e => {
					this.obj.push({
						content: e
					})
				})
				const obj = JSON.stringify(this.obj)
				// this.options = JSON.stringify(this.optionss) //将问卷题目选项等数据转化为json格式
				const { //发送请求创建调查问卷
					data: res
				} = await this.$request({
					url: '/user/question',
					method: 'PUT',
					data: {
						//必填项
						catalog_id: this.catalog_id, //分类列表的ID
						cover_url: this.cover_url, //封面图片的路径
						question_id: this.question_id, //当前问卷的ID
						expected_num: this.expected_num, //问卷的理想人数
						name: this.name, //问卷的名称
						options_str: obj, //问卷的题目和选项数据
						// ----------------------------------------------------------非必填项
						authority: this.switchval, //问卷是否私密
						start_date: this.datetimerange[0], //问卷开始时间
						end_date: this.datetimerange[1], //问卷结束时间
					},
				});
				//保存问卷回退到上一个页面
				if (this.expected_num != '' && obj != '' && this.cover_url != '') {
					uni.navigateBack()
				} else {
					uni.showToast({
						title: "您有信息未填写",
						icon: 'error'
					})
				}
			},
			cover() { //用来访问本机相册的方法
				uni.chooseImage({
					count: 1, //默认1
					sizeType: ['original', 'compressed'], //可以指定是原图还是压缩图，默认二者都有
					sourceType: ['album', 'camera '], //从相册选择
					success: (res) => {
						const data = res.tempFilePaths[0]
						uni.uploadFile({
							url: 'http://unisurvey.cinnabarpear.top/upload',
							header: {
								"Content-type": "application/x-www-form-urlencoded",
								"token": uni.getStorageSync('token')
							},
							fileType: "image",
							filePath: data,
							name: "file",
							success: (res) => {
								this.cover_url = JSON.parse(res.data).data
							}
						})
					}
				})
			}

		},
		components: {
			mycheckbox
		}
	}
</script>

<style lang="scss">
	page {
		height: 100%;
		position: relative;
		background-color: #F3F4F8;
	}

	.TJ-issue {
		position: absolute;
		bottom: 1px;
		width: 100%;
		height: 80%;
		background-color: #52A8FB;
	}

	.xs {
		margin-top: 20px;
		width: 80%;
		margin: auto;
		box-shadow: 4rpx 4rpx 10rpx lightgray;
		background-color: white;

		image {
			height: 70rpx;
			padding: 0 24rpx;
			width: 70rpx;
		}


		.xuanxiang {
			display: flex;
			padding: 12px 0;
			align-items: center;

			text {
				width: 460rpx;
				height: 80rpx;
				line-height: 80rpx;
				border: 2rpx solid lightgray;
			}
		}

	}

	.box {
		text-align: center;

		.text {
			font-family: "宋体";
			font-size: 56rpx;
			display: inline-block;
			box-sizing: border-box;
			padding: 40rpx 0;
		}

		.boxs {
			margin-top: 20px;
			display: flex;
			align-items: center;
			justify-content: flex-end;
			width: 80%;
			height: 150rpx;
			margin: auto;
			box-shadow: 4rpx 4rpx 10rpx lightgray;
			background-color: white;

			.bt {
				width: 460rpx;
				height: 120rpx;
				display: inline-block;
				line-height: 120rpx;
				font-size: 56rpx;
				color: black;
			}

			navigator {
				font-size: 24rpx;
				color: lightskyblue;
				padding-right: 20rpx;
			}

			text {
				width: 500rpx;
				height: 100rpx;
			}
		}

		.btss {
			display: inline-flex;
			flex-direction: column;

			text {
				height: 50rpx;
			}

			text:nth-child(even) {
				width: 500rpx;
				white-space: nowrap;
				overflow: hidden;
				text-overflow: ellipsis;
				font-size: 24rpx;
				color: lightgray;
			}
		}

		.box-buttom {
			width: 100%;
			position: absolute;
			display: flex;

			button {
				background-color: lightskyblue;
				color: white;
				width: 40%;
			}
		}

		.cover {
			width: 80%;
			margin: 100rpx auto;

			button {
				color: white;
				border-radius: 23px;
				background-color: #87CEFA;
			}
		}
	}

	.box-content {
		width: 80%;
		margin: auto;
		box-shadow: 4rpx 4rpx 10rpx lightgray;
		background-color: white;
		margin-top: 100rpx;

		text {
			height: 41.6rpx;
			width: 128rpx;
		}

		#box-content1 {
			display: flex;
			align-items: center;
			justify-content: space-around;
			width: 100%;
			height: 100rpx;
			border-bottom: 2rpx solid lightgray;
		}
	}
</style>
