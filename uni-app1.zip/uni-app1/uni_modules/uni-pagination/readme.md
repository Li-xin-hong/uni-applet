

## Pagination 分页器
> **组件名：uni-pagination**
> 代码块： `uPagination`


分页器组件，用于展示页码、请求数据等。

### [查看文档](https://uniapp.dcloud.io/component/uniui/uni-pagination)
#### 如使用过程中有任何问题，或者您对uni-ui有一些好的建议，欢迎加入 uni-ui 交流群：871950839 


